package com.jenkov.javafx;

public class ExampleRunner {

    public static void main(final String[] args) {
//	class each example main method you want from here and run this class's main from your IDE:
//	 for example to run ButtonExample uncomment the line below and run this class
//	ButtonExample.main(args);

    }

}
