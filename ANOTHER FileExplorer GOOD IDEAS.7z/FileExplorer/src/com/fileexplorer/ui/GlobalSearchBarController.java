package com.fileexplorer.ui;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;

import java.util.function.Consumer;

public class GlobalSearchBarController {

    @FXML private TextField searchField;
    @FXML private Button clearBtn;
    @FXML private Button searchBtn;

    private Consumer<String> onSearch;

    public void setOnSearch(Consumer<String> c) {
        this.onSearch = c;
    }

    @FXML
    private void initialize() {
        clearBtn.setVisible(false);

        searchField.textProperty().addListener((obs, oldVal, newVal) -> {
            clearBtn.setVisible(!newVal.isEmpty());
        });

        searchField.setOnAction(e -> triggerSearch());
    }

    @FXML
    private void onClearClick() {
        searchField.clear();
        if (onSearch != null) onSearch.accept("");
    }

    @FXML
    private void onSearchClick() {
        triggerSearch();
    }

    private void triggerSearch() {
        if (onSearch != null) {
            onSearch.accept(searchField.getText().trim());
        }
    }

    public void setQuery(String q) {
        searchField.setText(q);
    }
}