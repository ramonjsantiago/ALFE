package com.fileexplorer.ui;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.Region;

import com.fileexplorer.ui.CssModeManager;

public class RibbonBarController {

    @FXML private ToolBar ribbonBar;

    /* FILE GROUP */
    @FXML private Button btnNewFolder;
    @FXML private Button btnDelete;

    /* CLIPBOARD GROUP */
    @FXML private Button btnCopy;
    @FXML private Button btnPaste;
    @FXML private Button btnCut;

    /* VIEW GROUP */
    @FXML private Button btnViewDetails;
    @FXML private Button btnViewTiles;
    @FXML private Button btnViewContent;

    /* NAVIGATION GROUP */
    @FXML private Button btnUp;

    /* THEME SWITCH GROUP */
    @FXML private MenuItem menuLight;
    @FXML private MenuItem menuDark;
    @FXML private MenuItem menuGlassy;

    private CssModeManager cssModeManager;

    @FXML
    public void initialize() {

        // Scene might not be available immediately;
        ribbonBar.sceneProperty().addListener((_, _, newScene) -> {
            if (newScene != null) {
                cssModeManager = new CssModeManager(newScene);
            }
        });

        /* Theme switching */
        menuLight.setOnAction(_ -> safeApply(CssModeManager.Mode.LIGHT));
        menuDark.setOnAction(_ -> safeApply(CssModeManager.Mode.DARK));
        menuGlassy.setOnAction(_ -> safeApply(CssModeManager.Mode.GLASSY));

        /* FILE GROUP ACTIONS */
        btnNewFolder.setOnAction(_ -> fireCommand("new-folder"));
        btnDelete.setOnAction(_ -> fireCommand("delete"));

        /* CLIPBOARD GROUP */
        btnCopy.setOnAction(_ -> fireCommand("copy"));
        btnPaste.setOnAction(_ -> fireCommand("paste"));
        btnCut.setOnAction(_ -> fireCommand("cut"));

        /* VIEW GROUP */
        btnViewDetails.setOnAction(_ -> fireCommand("view-details"));
        btnViewTiles.setOnAction(_ -> fireCommand("view-tiles"));
        btnViewContent.setOnAction(_ -> fireCommand("view-content"));

        /* NAVIGATION */
        btnUp.setOnAction(_ -> fireCommand("nav-up"));
    }

    /** Safe wrapper so we don't crash early if scene not initialized. */
    private void safeApply(CssModeManager.Mode mode) {
        if (cssModeManager != null)
            cssModeManager.apply(mode);
    }

    /** EventBus hook (your actual bus implementation integrates here). */
    private void fireCommand(String command) {
        System.out.println("Ribbon: fireCommand -> " + command);

        // Replace with your actual event bus:
        // EventBus.getDefault().publish(new RibbonCommandEvent(command));
    }
}
