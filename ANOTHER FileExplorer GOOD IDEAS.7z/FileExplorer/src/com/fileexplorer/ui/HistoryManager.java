package com.fileexplorer.ui;

public class HistoryManager {

    public void recordAction(String action) {
        historyList.add(action);
        if (historyList.size() > MAX_HISTORY) historyList.remove(0);
            System.out.println(\"[History] \" + action);"
        }
}