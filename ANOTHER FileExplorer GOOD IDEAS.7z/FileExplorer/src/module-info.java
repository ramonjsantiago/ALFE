module FileExplorer {
    requires transitive org.junit.jupiter.api;

    requires transitive java.base;
    requires transitive java.desktop;
    requires transitive javafx.base;
    requires transitive javafx.controls;
    requires transitive javafx.fxml;
    requires transitive javafx.graphics;
    requires transitive javafx.swing;

    requires java.prefs;
    requires javafx.media;
    requires com.fasterxml.jackson.databind;
    requires javafx.web;

    opens com.fileexplorer.ui to javafx.fxml;
    opens com.fileexplorer.thumb to javafx.fxml;

    exports com.fileexplorer.ui;
    exports com.fileexplorer.thumb;
}